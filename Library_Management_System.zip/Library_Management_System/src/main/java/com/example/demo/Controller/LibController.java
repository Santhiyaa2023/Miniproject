package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.Service.LibService;
import com.example.demo.model.Library;


@Controller
public class LibController {
	
	@Autowired
	private LibService service;
	
	@GetMapping("/")
	public String viewHomepage(Model model) {
		
		List<Library> listlibrary=service.listAll();
		model.addAttribute("listlibrary",listlibrary);
		System.out.println("Get /");
		return "Frontpage";
	}
	@GetMapping("/new")
	public String add(Model model) {
		model.addAttribute("library",new Library());
		return "Nextpage";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String SaveLibrary(@ModelAttribute("library") Library lib) {
		service.save(lib);
		
		return "redirect:/";
}
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditLibraryPage(@PathVariable(name="id") int id) {
		ModelAndView LS = new ModelAndView("Nextpage");
		Library lib = service.get(id);
		LS.addObject("library",lib);
		return LS;
	}
	@RequestMapping("/delete/{id}")
	public String deletelibrary(@PathVariable(name="id") int id) {
		service.delete(id);
		return "redirect:/";
	}
}
