package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.LibRepository;
import com.example.demo.model.Library;

@Service
public class LibService {
	
	@Autowired
	private LibRepository repo;
	
	public List<Library> listAll(){
		
		return repo.findAll();
	}

	public void save(Library lib) {
		repo.save(lib);
		
	}
	public Library get(int id) {
		return repo.findById(id).get();
	}
	
	public void delete(int id) {
		repo.deleteById(id);
	}
}
