package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Library {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	// It allows the names between 2 and 15 characters long
	//@Size(min=2,max = 15)
	private String bookName;
	private String bookAuthor;
	private String cusName;
	private String startDate;
	private String endDate;
	
	private double amount;
	
	//No parameterize Constructor
	public Library() {
		
	}
	//Generate Constructors
	
	
	public Library(int id, String bookName, String bookAuthor, String cusName, String startDate, String endDate,
			double amount) {
		super();
		this.id = id;
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.cusName = cusName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
	}


	
	//Generate Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	//Generate toString()
	@Override
	public String toString() {
		return "Library [id=" + id + ", bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", cusName=" + cusName
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", amount=" + amount + "]";
	}
	
	
}
